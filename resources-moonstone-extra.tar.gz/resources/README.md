If using ilib for localization, localized resource files should be placed in this folder.
